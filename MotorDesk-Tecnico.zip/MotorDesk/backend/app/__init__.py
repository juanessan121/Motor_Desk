"""API central del taller."""
